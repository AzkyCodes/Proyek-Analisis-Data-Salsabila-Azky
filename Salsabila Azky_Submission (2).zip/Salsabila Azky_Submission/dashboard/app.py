import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Dataset
day_df = pd.read_csv(r'C:\Users\ASUS\Desktop\miniconda3\Salsabila Azky_Submission\datasetBike\day.csv')

# Pengelompokkan data untuk suhu, kelembapan, dan kecepatan angin
temp_group = day_df.groupby(pd.cut(day_df['temp'], bins=5), observed=True).agg({
    'casual': 'mean',
    'registered': 'mean'
}).reset_index()

if_hum = day_df.groupby(pd.cut(day_df['hum'], bins=5), observed=True).agg({
    'casual': 'mean',
    'registered': 'mean'
}).reset_index()

if_wind = day_df.groupby(pd.cut(day_df['windspeed'], bins=5), observed=True).agg({
    'casual': 'mean',
    'registered': 'mean'
}).reset_index()

# Rata-rata jumlah penyewaan sepeda
casual_mean = day_df['casual'].mean()
registered_mean = day_df['registered'].mean()

# Dataframe pengguna kasual dan terdaftar
combined_df = pd.DataFrame({
    'Kategori': ['Pengguna Kasual', 'Pengguna Terdaftar'],
    'Rata-rata': [casual_mean, registered_mean]
})

# Tampilan di streamlit
st.title('Dashboard Penyewaan Sepeda')

# Diagram
st.header('Rata-rata Penyewaan Sepeda')
fig, ax = plt.subplots()
combined_df.set_index('Kategori').plot(kind='bar', color=['skyblue', 'purple'], ax=ax)
ax.set_title('Perbedaan Rata-rata Penyewaan Sepeda antara Pengguna Kasual dan Terdaftar')
ax.set_xlabel('Kategori Pengguna')
ax.set_ylabel('Rata-rata Penyewaan Sepeda')
plt.xticks(rotation=0)
st.pyplot(fig)

# Histogram 
st.header('Pengaruh Suhu, Kelembapan dan Kecepatan Angin Terhadap Penyewaan Sepeda')

# Suhu
fig, ax = plt.subplots(figsize=(5, 5))
temp_labels = [f'{(bin.left + bin.right) / 2:.2f} °C' for bin in temp_group['temp']]
ax.bar(temp_labels, temp_group['casual'], color='brown', alpha=0.6, label='Kasual')
ax.bar(temp_labels, temp_group['registered'], color='orange', alpha=0.6, label='Terdaftar')
ax.set_title('Pengaruh Suhu Terhadap Minat Bersepeda')
ax.set_xlabel('Suhu (°C)')
ax.set_ylabel('Rata-Rata Penyewaan')
plt.xticks(rotation=45)
ax.legend()
st.pyplot(fig)

# Kelembapan
fig, ax = plt.subplots(figsize=(5, 5))
hum_labels = [f'{(bin.left + bin.right) / 2:.2f}%' for bin in if_hum['hum']]
ax.bar(hum_labels, if_hum['casual'], color='brown', alpha=0.6, label='Kasual')
ax.bar(hum_labels, if_hum['registered'], color='orange', alpha=0.6, label='Terdaftar')
ax.set_title('Pengaruh Kelembapan Terhadap Minat Bersepeda')
ax.set_xlabel('Kelembapan (%)')
ax.set_ylabel('Rata-Rata Penyewaan')
plt.xticks(rotation=45)
ax.legend()
st.pyplot(fig)

# Kecepatan Angin
fig, ax = plt.subplots(figsize=(5, 5))
wind_labels = [f'{(bin.left + bin.right) / 2:.2f} m/s' for bin in if_wind['windspeed']]
ax.bar(wind_labels, if_wind['casual'], color='brown', alpha=0.6, label='Kasual')
ax.bar(wind_labels, if_wind['registered'], color='orange', alpha=0.6, label='Terdaftar')
ax.set_title('Pengaruh Kecepatan Angin Terhadap Minat Bersepeda')
ax.set_xlabel('Kecepatan Angin (m/s)')
ax.set_ylabel('Rata-Rata Penyewaan')
plt.xticks(rotation=45)
ax.legend()
st.pyplot(fig)