## Dashboard data penyewaan sepeda  - Salsabila Azky Quri'al Qur'ani


# Envirovement Python 
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# Setup Envirovement Terminal

conda create miniconda3
conda activate miniconda3\env
conda install -r requirements.txt


# Run Streamlit
streamlit run app.py